<?php
// Initialize cURL session
$ch = curl_init();

// Set the URL you want to connect to
$url = 'http://172.16.93.25:8080/'; // Replace with your desired URL

// Define the POST data as an associative array
$postData = array(
    'POST' => '1',
    'GET' => '2'
);

// Convert the POST data to a URL-encoded string
$postDataString = http_build_query($postData);

// Append the POST data to the URL if you want to send it as a GET parameter
$url .= 'http://172.16.93.25:8080/'' . $postDataString;

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response as a string
// You can add more options here as needed

// Execute cURL session and store the response in $response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
}

// Close cURL session
curl_close($ch);

// Output the response
echo $response;
?>
