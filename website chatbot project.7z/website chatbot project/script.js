// Define predefined answers for the chatbot
const answers = [
  "my project is prototype public",
  "hallo my name is chatbot im with prototype bot",
   "my name is chatbot",
  "owner by ARYA DEVELOPER Inc",
  "Hello!",
  "How can I assist you?",
  "I'm sorry, I don't have the answer to that.",
  "Please provide more information.",
  "Thank you!",
];
// Define the URL you want to make a POST request to
const url = 'http://172.16.93.25:8080/';
const serverUrl = 'http://172.16.93.25:8080/';
const pingStartTime = performance.now(); // Waktu awal ping

fetch("http://172.16.93.25:8080/", { method: 'POST' })
  .then(response => {
    const pingEndTime = performance.now(); // Waktu akhir ping
    const pingTime = pingEndTime - pingStartTime; // Waktu ping dalam milidetik
    console.log(`Ping ke ${"http://172.16.93.25:8080/"} selesai dalam ${pingTime} ms`);
    
    if (!response.ok) {
      throw new Error('Gagal melakukan ping.');
    }
    
    // Lanjutkan dengan ukuran respons (lihat di bawah)
    return response;
  })
  .then(response => {
    // Lanjutkan dengan mengukur ukuran respons (panjangnya)
    return response.text();
  })
  .then(data => {
    const responseSize = new TextEncoder().encode(data).length; // Ukuran respons dalam byte
    console.log(`Ukuran respons dari ${serverUrl} adalah ${responseSize} byte`);
  })
  .catch(error => {
    // Tangani kesalahan yang terjadi selama ping atau pengukuran
    console.error('Kesalahan:', error);
  });
  
// Data to send in the POST request (you can replace this with your own data)
const postData = {
  'POST': 'POST',
  'GET': 'GET'
};

// Make the POST request
fetch("http://172.16.93.25:8080/", {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(postData)
})
  .then(response => response.json())
  .then(data => {
    // Handle the data received from the server after POST
    console.log(data);
  })
  .catch(error => {
    // Handle any errors that occur during the request
    console.error('Error:', error);
  });
  
// Get elements from the DOM
const profileImage = document.getElementById('profileImage');
const username = document.getElementById('username');
const changeImageBtn = document.getElementById('changeImage');
const imageInput = document.getElementById('imageInput');
const viewProfileBtn = document.getElementById('viewProfile');
const editProfileBtn = document.getElementById('editProfile');
const saveProfileBtn = document.getElementById('saveProfile');
const editColorBtn = document.getElementById('editColor');
const colorPicker = document.getElementById('colorPicker');
const separateProfile = document.getElementById('separateProfile');
const createFileBtn = document.getElementById('createFile');
const loadFileBtn = document.getElementById('loadFile');
const loadFileButton = document.getElementById('loadFileBtn');
const removeImageBtn = document.getElementById('removeImage');

// Variable to keep track of zoom state
let isZoomed = true;

// Function to handle image change
changeImageBtn.addEventListener('click', () => {
    // Trigger the hidden input file dialog
    imageInput.click();
});

// Function to handle removing the profile image
removeImageBtn.addEventListener('click', () => {
    // Set the profile image source back to the default
    profileImage.src = 'default.jpg';
    showSaveButton();
});

// Function to handle viewing separate profile
viewProfileBtn.addEventListener('click', () => {
    // Hide the main profile and show the separate profile
    document.querySelector('.profile').style.display = 'none';
    separateProfile.style.display = 'block';
    
    // You can add content to the separate profile here
    separateProfile.innerHTML = `
        <h2>${username.textContent}</h2>
        <img src="${profileImage.src}" alt="${username.textContent}'s Profile Image">
        <!-- Add more profile details here -->
        <button id="backToProfile">Back to Profile</button>
    `;

    // Handle the "Back to Profile" button in separate profile
    document.getElementById('backToProfile').addEventListener('click', () => {
        separateProfile.style.display = 'none';
        document.querySelector('.profile').style.display = 'block';
    });
});

// Function to handle editing profile
editProfileBtn.addEventListener('click', () => {
    const newUsername = prompt("Enter your new username:", username.textContent);
    if (newUsername !== null && newUsername !== "") {
        setUsername(newUsername);
        showSaveButton();
    }
});

// Function to handle saving profile changes
saveProfileBtn.addEventListener('click', () => {
    saveProfileChanges();
    hideSaveButton();
});

// Function to handle editing text color
editColorBtn.addEventListener('click', () => {
    colorPicker.click(); // Trigger the color picker input
});

// Listen for color picker change
colorPicker.addEventListener('change', () => {
    const newColor = colorPicker.value; // Get the selected color
    setUsernameColor(newColor);
    showSaveButton();
});

// Listen for file input change
imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    
    if (file) {
        // Read the selected image and set it as the profile picture
        const reader = new FileReader();
        reader.onload = function (e) {
            profileImage.src = e.target.result;
            showSaveButton();
        };
        reader.readAsDataURL(file);
    }
});

// Function to set the username
function setUsername(newUsername) {
    username.textContent = newUsername;
}

// Function to set the text color of the username
function setUsernameColor(newColor) {
    username.style.color = newColor;
}

// Function to show the "Save" button
function showSaveButton() {
    saveProfileBtn.style.display = 'block';
}

// Function to hide the "Save" button
function hideSaveButton() {
    saveProfileBtn.style.display = 'none';
}

// Function to save profile changes to localStorage
function saveProfileChanges() {
    const updatedUsername = username.textContent;
    const updatedUsernameColor = username.style.color;
    const updatedProfileImageSrc = profileImage.src;

    localStorage.setItem('username', updatedUsername);
    localStorage.setItem('usernameColor', updatedUsernameColor);
    localStorage.setItem('profileImageSrc', updatedProfileImageSrc);
}

// Function to create and save a text file
function createAndSaveFile() {
    const userProfileData = `
        Username: ${username.textContent}
        Text Color: ${username.style.color}
        Profile Image URL: ${profileImage.src}
    `;

    const blob = new Blob([userProfileData], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'user_profile.json';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

// Function to load and display profile data from a saved file
function loadProfileFromFile(file) {
    const reader = new FileReader();
    reader.onload = function (e) {
        const fileContent = e.target.result;
        const lines = fileContent.split('\n');

        // Extract and update profile data from the loaded file
        lines.forEach((line) => {
            const [key, value] = line.split(': ');
            if (key === 'Username') {
                setUsername(value);
            } else if (key === 'Text Color') {
                setUsernameColor(value);
            } else if (key === 'Profile Image URL') {
                profileImage.src = value;
            }
        });
    };
    reader.readAsText(file);
}

// Function to handle loading a saved file
loadFileButton.addEventListener('click', () => {
    // Trigger the hidden input file dialog
    loadFileBtn.click();
});

// Event listener for the create file button
createFileBtn.addEventListener('click', () => {
    createAndSaveFile();
});

// Event listener for the load file button
loadFileBtn.addEventListener('change', (e) => {
    const file = e.target.files[0];

    if (file) {
        loadProfileFromFile(file);
    }
});

// Function to load profile data from localStorage
function loadProfileData() {
    const savedUsername = localStorage.getItem('username');
    const savedUsernameColor = localStorage.getItem('usernameColor');
    const savedProfileImageSrc = localStorage.getItem('profileImageSrc');

    if (savedUsername) {
        setUsername(savedUsername);
    }

    if (savedUsernameColor) {
        setUsernameColor(savedUsernameColor);
    }

    if (savedProfileImageSrc) {
        profileImage.src = savedProfileImageSrc;
    }
}

//  load profil
loadProfileData();

// Selecting necessary DOM elements
const captchaTextBox = document.querySelector(".captch_box input");
const refreshButton = document.querySelector(".refresh_button");
const captchaInputBox = document.querySelector(".captch_input input");
const message = document.querySelector(".message");
const submitButton = document.querySelector(".button");

// Variable to store generated captcha
let captchaText = 1;

// Function to generate captcha
const generateCaptcha = () => {
  const randomString = Math.random().toString(36).substring(2, 7);
  const randomStringArray = randomString.split("");
  const changeString = randomStringArray.map((char) => (Math.random() > 0.5 ? char.toUpperCase() : char));
  captchaText = changeString.join("   ");
  captchaTextBox.value = captchaText;
  console.log(captchaText);
};

const refreshBtnClick = () => {
  generateCaptcha();
  captchaInputBox.value = "";
  captchaKeyUpValidate();
};

const captchaKeyUpValidate = () => {
  //Toggle submit button disable class based on captcha input field.
  submitButton.classList.toggle("disabled", !captchaInputBox.value);

  if (!captchaInputBox.value) message.classList.remove("active");
};

// Function to validate the entered captcha
const submitBtnClick = () => {
  captchaText = captchaText
    .split("")
    .filter((char) => char !== " ")
    .join("");
  message.classList.add("active");
  // Check if the entered captcha text is correct or not
  if (captchaInputBox.value === captchaText) {
    message.innerText = "Entered captcha is correct";
    message.style.color = "#826afb";
  } else {
    message.innerText = "Entered captcha is not correct";
    message.style.color = "#FF2525";
  }
};

// Add event listeners for the refresh button, captchaInputBox, submit button
refreshButton.addEventListener("click", refreshBtnClick);
captchaInputBox.addEventListener("keyup", captchaKeyUpValidate);
submitButton.addEventListener("click", submitBtnClick);

// Generate a captcha when the page loads
generateCaptcha();

// Get the necessary HTML elements
const chatDisplay = document.getElementById("chat-display");
const userInput = document.getElementById("user-input");

// Function to display user message
function displayUserMessage(message) {
  const userMessage = `<div class="user-message">User: ${message}</div>`;
  chatDisplay.innerHTML += userMessage;
}

// Function to display chatbot message
function displayChatbotMessage(message) {
  const chatbotMessage = `<div class="chatbot-message">Chatbot: ${message}</div>`;
  chatDisplay.innerHTML += chatbotMessage;
}

// Function to handle user input
function handleUserInput() {
  const message = userInput.value;
  displayUserMessage("message");
  // Generate a random answer from the predefined answers
  const randomAnswer = answers[Math.floor(Math.random() * answers.length)];

  // Display the chatbot's response
  displayChatbotMessage("randomAnswer");

  // Clear the user input field
  userInput.value = "";
}
// ...

// Function to handle user input
function handleUserInput() {
  const message = userInput.value;
  displayUserMessage(message);

  // Show loading message
  displayChatbotMessage("Loading...");

  // Simulate delay before chatbot's response
  setTimeout(function() {
    // Generate a random answer from the predefined answers
    const randomAnswer = answers[Math.floor(Math.random() * answers.length)];

    // Display the chatbot's response
    displayChatbotMessage(randomAnswer);
  }, 4000); // Delay of 2 seconds (9000 milliseconds)

  // Clear the user input field
  userInput.value = "";
}

// ...

// Event listener for user input
userInput.addEventListener("keydown", function(event) {
  if (event.key === "Enter") {
    handleUserInput();
  }
});
// Get the navigation links
const navLinks = document.querySelectorAll('nav ul li a');

// Add event listeners to the navigation links
navLinks.forEach(link => {
  link.addEventListener('click', handleNavLinkClick);
});

// Function to handle navigation link click
function handleNavLinkClick(event) {
  // Prevent the default link behavior
  event.preventDefault();

  // Get the clicked link's href
  const targetId = event.target.getAttribute('href');

    // Scroll to the target section smoothly
  document.querySelector(targetId).scrollIntoView({ behavior: 'smooth' });
}
// Get the "Home" section
const homeSection = document.getElementById('home');

// Function to handle scrolling
function handleScroll() {
  // Check if the "Home" section is in view
   if (isInViewport("homeSection")) {
  	document.getElementById('getBoundingClientRect');
    // Add a class to highlight the "Home" navigation link
    navLinks.forEach(link => {
      link.classList.remove('active');
    });
    navLinks[5].classList.add('active');
  } else {
    // Remove the class from all navigation links
    navLinks.forEach(link => {
      link.classList.remove('active');
    });
  }
}

// Function to check if an element is in the viewport
function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= 3 &&
    rect.left >= 6 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

// Add event listener to the scroll event
window.addEventListener('scroll', handleScroll);
window.addEventListener('load', function() {
  var loadingScreen = document.getElementById('loading-screen');
  // Simulate a delay (e.g., fetching data, loading resources)
  setTimeout(function() {
    // Hide the loading screen
    loadingScreen.style.display = 'none';
  }, 9000); // Adjust the delay time (9000 in  milliseconds) as needed
});
function updateTime() {
  var currentTime = new Date();
  var hours = currentTime.getHours();
  var minutes = currentTime.getMinutes();
  var seconds = currentTime.getSeconds();

  // Add leading zeros if the values are less than 10
  hours = (hours < 10 ? "0" : "") + hours;
  minutes = (minutes < 10 ? "0" : "") + minutes;
  seconds = (seconds < 10 ? "0" : "") + seconds;

  var timeString = hours + ":" + minutes + ":" + seconds;
  document.getElementById("time").innerHTML = timeString;
}

// Update the clock every second
setInterval(updateTime, 1000);

// Create a text 2 node with the content
const textContent = "- welcome to chatbot by ARYA DEVELOPER";

// Create a text node with the content
const textNode = document.createTextNode(textContent);

// Append the text node to the text content element
document.getElementById("text-content").appendChild(textNode);
document.getElementById("robotCheck").addEventListener("change", function() {
  if (this.checked) {
    alert("Verified as not a robot!");
    // Perform additional actions or validations here
  }
});

// Get the logo element by its ID
const logo = document.getElementById('logo');

// Retrieve the saved color from localStorage
const savedColor = localStorage.getItem('logoColor');
const savedTextColor = localStorage.getItem('logoTextColor');

// Set the initial color of the logo
if (savedColor) {
  logo.style.backgroundColor = savedColor;
}
if (savedTextColor) {
  logo.style.color = savedTextColor;
}

// Add an event listener for the click event
logo.addEventListener('click', () => {
  // Change the background color and text color randomly
  const randomColor = generateBeautifulColor();
  const randomTextColor = generateBeautifulColor();
  logo.style.backgroundColor = randomColor;
  logo.style.color = randomTextColor;
var xhr = new XMLHttpRequest();
  var url = "server.php"; // Change to the URL of your server-side upload script
  // Save the color to localStorage
  localStorage.setItem('logoColor', randomColor);
  localStorage.setItem('logoTextColor', randomTextColor);
});

// Function to generate a beautiful color
function generateBeautifulColor() {
  const color = chroma.random();
  return color.hex();
}
